import pymongo
from pymongo import MongoClient
from bson.objectid import ObjectId

#declaring class
class AnimalShelter(object):
    #CRUD operation for animal collection in MongoDB
    
    def __init__(self,username=None, password=None):
        
        #initializing the mongoclient. THis helps to access the MongoDB databases and collections
       # if username and password:
       self.client = MongoClient('mongodb://%s:%s@localhost:39657/AAC'%(username, password))
        
       self.database = self.client['AAC']
        
    #completing create method to implement the C in CRUD
    def create(self,data):
        if data is not None:
            insert = self.database.animals.insert(data)
            #data should be dictionary
            
            #if insert is not 0 return true, anything else return false
            if insert !=0:
                return True
            else:
                return False
        else:
            raise Exception('Nothing to save, because data parameter is empty')
            
    #create method to implement R in CRUD
    def read(self, criteria = None):
        
        #if criteria is not none, this find returns all row that match the criteria
        if criteria:
            
            data = self.database.animals.find(criteria,{"_id":False})
            
        else:
            #return all rows if no serach criteria
            data = self.database.animals.find( {} ,{"_id":False})
            
        return data
    
    
    #update method to implment the U in CRUD
    def update(self, initial, change):
        #if there is an input do the following
        if initial is not None:
            #if you find the input update it with the information provided
            if self.database.animals.count_documents(initial, limit = 1) !=0:
                update_result = self.database.animals.update_many(initial, {'$set': change})
                result = update_result.raw_result
            #if you can't find the input return that the document couldn't be found
            else:
                result = "No document was found"
            #return the result of the if statement
            return result
        #if the function is empty return the error message that nothing was entered
        else:
            raise Exception ("Nothing to update, because data parameter is empty")
    
    
    #delete method to implement the D in CRUD
    def delete(self, remove):
        #if there is an input do the following
        if remove is not None:
            #if the input is found delete it
            if self.database.animals.count_documents(remove, limit = 1) !=0:
                delete_result = self.database.animals.delete_many(remove)
                result = delete_result.raw_result
            #if you can't find the input return that the document couldn't be found
            else:
                result = "No document was found"
            #return the result of the if statement    
            return result
        #if the function is empty return the error message that nothing was entered
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
            
        